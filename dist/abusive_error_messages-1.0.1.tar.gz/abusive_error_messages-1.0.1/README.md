# Abusive-Error-Messages

Replaces all error messages with unhelpful, insulting, abusive error messages.

Made as an April Fool's joke.

## Disclaimers
- Don't actually use this
- This is a joke
- This is not "safe for the workplace"
- Don't use this if you don't have a sense of humor
- I disclaim all hurt feelings


## Installation

```console
pip install abusive-error-messages
```

## Usage
```python
import abusive_error_messages
1/0
```

## License

`abusive-error-messages` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
